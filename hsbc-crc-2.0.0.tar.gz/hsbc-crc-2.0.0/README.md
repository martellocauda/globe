# HSBC CRC - Production Package

## Instalación

1. Descomprimir el paquete en el servidor
2. Instalar dependencias de producción:
   ```bash
   cd server
   npm install --production
   ```

3. Configurar conexiones en `server/config.json`
   - Actualizar credenciales de bases de datos (AS400, MySQL, MongoDB)
   - Verificar `active_connection` index
   - Configurar `PORT` si es necesario

## Despliegue con PM2

```bash
# Desde el directorio raíz del paquete
pm2 start process.json --env production

# Ver logs
pm2 logs hsbc-crc-server

# Reiniciar
pm2 restart hsbc-crc-server

# Detener
pm2 stop hsbc-crc-server
```

## Acceso

- Frontend: http://localhost:4001
- API: http://localhost:4001 (rutas bajo /execution)

## Estructura

```
hsbc-crc/
├── server/
│   ├── dist/              # Backend transpilado (Babel)
│   │   └── frontend/      # Frontend compilado (React)
│   ├── queries/           # Archivos SQL
│   ├── config.json        # Configuración
│   ├── package.json       # Dependencias
│   └── node_modules/      # Dependencias de producción (después de npm install)
└── process.json           # Configuración PM2
```

## Troubleshooting

- Verificar conexiones a bases de datos en `server/config.json`
- Revisar logs con `pm2 logs hsbc-crc-server`
- Verificar puerto 4001 disponible
- Asegurar que MongoDB esté accesible
